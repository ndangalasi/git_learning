function myReplace(str, before, after) {
 var index = str.indexOf(before);
 if(str[index] === str[index].toUpperCase()){
	 after = after.charAt(0).toUpperCase() + after.slice(1);
 }
 var newSen=str.replace(before,after);
  console.log(newSen);
  return newSen;
}

myReplace("He is Sleeping on the couch", "Sleeping", "sitting");