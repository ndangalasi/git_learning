function pairElement(str) {
	var arr=[];
	for(var i = 0; i<str.length; i++ ){
		if(str[i] === A){
			arr.push(["A","T"])
		}
	}
	console.log(arr);
  return arr;
}

pairElement("a");