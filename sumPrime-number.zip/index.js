function sumPrimes(num) {
	var numArr =[];
	for(i=2;i<=num; i++){
		if(isPrime(i)){
			numArr.push(i);
		}
	}
	function isPrime(num){
		for(var j=2; j<num; j++){
			if(num%j===0){
				return false;
			}
		}
		return true;
	}
	return numArr.reduce(function(a,b){return a+b});
	
}

sumPrimes(10);